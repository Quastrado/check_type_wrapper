from setuptools import find_packages, setup


setup(
    name='Quastrado_check_type_wrapper',
    version='0.1',
    author='Quastrado',
    author_email='quastrado@gmail.com', 
    description='Package Description',
    url='',
    packages=find_packages()
)
