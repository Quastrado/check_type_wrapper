

class DiscrepancyItem():
    def __init__(self, argument=None, expected_type=None, argument_type=None):
        self.argument = argument
        self.expected_type = expected_type
        self.argument_type = argument_type
